import java.util.*;

class Two_Stacks
{
int []arr;
int size;
int Top1,Top2;

Two_Stacks(int n)
{
size=n;
arr=new int[n];
Top1=n/2 +1;
Top2=n/2;

}

void push1(int x)
{
if(Top1>0)
{
Top1--;
arr[Top1] = x;

}
else
{
	
	System.out.println("Stack overflow by element :"+x);
	return;
}

}

void push2(int x)
{
	if(Top2 < size-1)
{
	Top2++;
	arr[Top2]=x;
	
}
else
{
	
System.out.println("Stack overflow by element :"+x);
return;	
}
}


int pop1()
{
	
	
	if(Top1<=size/2)
	{
		int x=arr[Top1];
		Top1++;
		return x;
	}
	
	else
	{
		System.out.println("Stack underfow is occured");
		System.exit(1);
		
	}
	return 0;
}

int pop2()
{
	if(Top2 >=size / 2 +1)
	{
		int x = arr[Top2];
		Top2--;
		return x;
		
	}
	else
	{
		System.out.println("Stack underflow");
		System.exit(1);
		
	}
	return 1;
}
}

class Two_Stacks_Demo
{
	public static void main(String args[])
	{
		Two_Stacks t1 =new Two_Stacks(5);
		t1.push1(5);
		t1.push2(10);
		t1.push2(15);
		t1.push1(11);
		t1.push2(7);
		t1.push2(40);
		
		
		System.out.println("Popped elements from stack1 is "+t1.pop1());
		
	
		
		System.out.println("Popped elements from stack2 is "+t1.pop2());
		
	}
	
	
}
