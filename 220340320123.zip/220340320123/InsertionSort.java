import java.util.Scanner;

public class InsertionSort
{
public static void insertSorted(int[]ar)
{
int length =ar.length;
int element = ar[length-1];

for(int i = length-2;i>=0;i--)
{
if(ar[i]> element)
{
ar[i+1] = ar[i];
System.out.println(ar);
}

else
{
ar[i+1] = element;
System.out.println(ar);
break;

}

if((i ==0) && (ar[i]> element))
{
ar[i] = element;
System.out.println(ar);

}
}

}

public static void main(String args[])
{
Scanner sc = new Scanner(System.in);
int s=sc.nextInt();
int[]ar= new int[s];

for(int i=0; i<s;i++)
{
ar[i]=sc.nextInt();

}
insertSorted(ar);
sc.close();
}
private static void printArray(int[] ar)
{
for(int n : ar)
{
System.out.println(n+" ");
}
System.out.println(" ");
}


}